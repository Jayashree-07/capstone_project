package com.capstone;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class AadharRegister {
	static WebDriver webdriver = null;

	@Test
	public void ChromeBrowser() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\DELL\\Downloads\\chromedriver_win32\\chromedriver.exe");
		webdriver = new ChromeDriver();
		webdriver.manage().window().maximize();
		Thread.sleep(1000);
		System.out.println("Chrome Browser is Opened!!");
		
	}
	
	@Test
	public void TestHome() throws InterruptedException {
		webdriver.get("http://localhost:4200/home");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		webdriver.findElement(By.xpath("//a[@routerlink='/register']")).click();
		Thread.sleep(1000);
		webdriver.get("http://localhost:4200/register");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		webdriver.findElement(By.id("name")).sendKeys("Vijay");
		webdriver.findElement(By.id("dob")).sendKeys("09/08/2000");
		webdriver.findElement(By.id("emailid")).sendKeys("vijay@gmail.com");
		webdriver.findElement(By.id("address")).sendKeys("South Street,Kerala");
		webdriver.findElement(By.id("mobileno")).sendKeys("65433568215");
		webdriver.findElement(By.id("gender")).sendKeys("Male");
		
		webdriver.findElement(By.xpath("//button[@id='register']")).click();
		Thread.sleep(1000);
	}



}
